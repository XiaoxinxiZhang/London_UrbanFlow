UrbanFlow 每日健康出行建议（追加模块）

1. 把整个 urbanflow_health_addon 文件夹放在当前 London_UrbanFlow-main（或 London_UrbanFlow_Ready）目录里面。
2. 双击 urbanflow_health_addon/07_INSTALL_HEALTH.bat。
3. 脚本会新增 assets/health_advice.js、assets/health_advice.css、tools/health_advice.py、tools/import_health_2025.py，
   并在原 index.html、tools/server.py、assets/city.js 中插入少量必要的引用、接口和地图点击事件。
4. 请关闭原来的服务窗口，然后重新双击 02_OPEN_DASHBOARD.bat，并在网页按 Ctrl+F5 刷新。
5. 打开「城市总览」，在地图下面看到「每日空气质量与健康出行建议」。点击地图的空气监测站，会同步切换站点；也可以独立选择站点和日期。

2025年历史数据（可选）：
脚本会自动搜索之前项目保存的 london_2025_hourly.csv，优先选择 PM 数据比较完整的一份，复制到当前项目 data/health/defra_2025_hourly.csv。
如果没找到历史数据，也能查看当前SQLite中已经采集的 LAQN 等监测数据。
如需指定你的2025 CSV文件，在当前项目根目录运行：
  python tools/import_health_2025.py "C:\你的路径\london_2025_hourly.csv"
或者双击 08_IMPORT_2025_HEALTH.bat，指定文件路径作为参数。
导入后请重启本地服务（或刷新网页，后端首次读取新文件时会自动加载）。

新增功能：
- 按日期和站点展示 PM2.5、PM10、NO2、O3
- 根据英国政府 DAQI 1-10 等级划分，颜色为绿/黄/红/紫
- 不同人群：普通人群、儿童与青少年、老年人、呼吸系统疾病、心血管疾病、户外运动与工作人群
- 每个人群提供出行建议和防护措施
- 地图点选联动；可上一天/下一天切换，支持历史数据

官方依据（2026年4月13日更新）：
https://www.gov.uk/government/publications/health-effects-of-air-pollution/using-the-daily-air-quality-index-daqi
https://www.gov.uk/government/publications/health-effects-of-air-pollution/health-advice-for-the-daily-air-quality-index-daqi
https://www.gov.uk/government/publications/health-effects-of-air-pollution/pollutant-concentrations-for-the-daily-air-quality-index-daqi

恢复旧版：
自动安装前创建在 health_backup/ 文件夹内的备份可按文件名还原（例如 index.html.before_health.bak）。
不会重置或改写 SQLite 数据库，也不会修改空气质量或自行车采集器。
