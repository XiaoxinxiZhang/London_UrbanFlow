# -*- coding: utf-8 -*-
"""Daily travel/health suggestions; additive companion to UrbanFlow's existing SQLite API.

Data sources: existing `measurements` records; optional local Defra 2025 hourly CSV.
No new third-party dependencies or database-schema changes.
"""
from __future__ import annotations
import csv
from collections import defaultdict
from datetime import date, datetime, timedelta, timezone
from functools import lru_cache
import math
from pathlib import Path
import sqlite3

METRICS = ('PM25', 'PM10', 'NO2', 'O3')
NAMES = {'PM25': 'PM₂.₅', 'PM10': 'PM₁₀', 'NO2': 'NO₂', 'O3': 'O₃'}
# 1..9 upper endpoints, official integer µg/m³ bands. Level 10 above last limit.
LIMITS = {
    'PM25': (11, 23, 35, 41, 47, 53, 58, 64, 70),
    'PM10': (16, 33, 50, 58, 66, 75, 83, 91, 100),
    'NO2': (67, 134, 200, 267, 334, 400, 467, 534, 600),
    'O3': (33, 66, 100, 120, 140, 160, 187, 213, 240),
}
BANDS = {'low': '低', 'moderate': '中等', 'high': '高', 'very_high': '很高', 'missing': '暂无数据'}
SITE_NAMES = {'HRL': 'Harlington 哈灵顿', 'KC1': 'North Kensington 北肯辛顿',
              'MY1': 'Marylebone Road 马里波恩路', 'CLL2': 'Bloomsbury 布卢姆斯伯里',
              'BEX': 'Bexley 贝克斯利', 'HIL': 'Hillingdon 希灵登',
              'HG4': 'Haringey Priory Park South', 'HORS': 'Westminster 威斯敏斯特',
              'TED2': 'Teddington Bushy Park', 'HP1': 'Honor Oak Park'}


def score(metric, value):
    if metric not in LIMITS or value is None:
        return None
    try:
        x = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(x) or x < 0:
        return None
    # DAQI limits published as whole µg/m³, round to nearest whole µg/m³.
    n = math.floor(x + 0.5)
    for level, upper in enumerate(LIMITS[metric], 1):
        if n <= upper:
            return level
    return 10


def band(level):
    if level is None:
        return 'missing'
    return 'low' if level <= 3 else 'moderate' if level <= 6 else 'high' if level <= 9 else 'very_high'


def normalize_metric(name):
    code = str(name or '').upper().replace('.', '').replace('_', '').replace(' ', '')
    if 'INDEX' in code:
        return None
    for k in METRICS:
        if code.startswith(k):
            return k
    return None


def valid_number(value):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) and 0 <= number < 10000 else None


def utc_hour(raw):
    try:
        stamp = datetime.fromisoformat(str(raw).replace('Z', '+00:00'))
        if stamp.tzinfo is None:
            stamp = stamp.replace(tzinfo=timezone.utc)
        return stamp.astimezone(timezone.utc).replace(minute=0, second=0, microsecond=0)
    except (ValueError, TypeError):
        return None


def to_hourly(raw, *, historical=False):
    """Unify 15-min/h entries; prefer native 1-hour values, then aggregate quarters."""
    buckets = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
    for row in raw:
        metric = normalize_metric(row.get('metric'))
        if not metric:
            continue
        value = valid_number(row.get('value'))
        stamp = utc_hour(row.get('timestamp'))
        if value is None or stamp is None:
            continue
        period = int(row.get('period') or 3600)
        buckets[metric][stamp]['hour' if period == 3600 else 'quarter' if period == 900 else 'other'].append(value)
    result = defaultdict(dict)
    for metric, hourly in buckets.items():
        for stamp, by_period in hourly.items():
            if by_period['hour']:
                value = by_period['hour'][-1]
            elif len(by_period['quarter']) >= 2:
                value = sum(by_period['quarter']) / len(by_period['quarter'])
            elif by_period['other']:
                value = by_period['other'][-1]
            else:
                continue
            result[metric][stamp] = value
    return result


def _max_running_8(hourly, start, end):
    best = None
    hour = start
    while hour < end:
        values = [hourly.get(hour - timedelta(hours=k)) for k in range(8)]
        observed = [x for x in values if x is not None]
        if len(observed) >= 6:
            average = sum(observed) / len(observed)
            best = max(best, average) if best is not None else average
        hour += timedelta(hours=1)
    return best


def _daily_metrics(hourly, day):
    start = datetime.combine(day, datetime.min.time(), tzinfo=timezone.utc)
    end = start + timedelta(days=1)
    current_utc_day = datetime.now(timezone.utc).date() == day
    out = []
    for metric in METRICS:
        values = hourly.get(metric, {})
        period_values = [v for k, v in values.items() if start <= k < end]
        count = len(period_values)
        label = {'PM25': '日均浓度', 'PM10': '日均浓度', 'NO2': '最大小时浓度', 'O3': '最大8小时均值'}[metric]
        result = None
        if metric in ('PM25', 'PM10'):
            if current_utc_day and values:
                last_hour = max((h for h in values if start <= h < end), default=None)
                if last_hour is not None:
                    rolling = [v for h, v in values.items() if last_hour - timedelta(hours=23) <= h <= last_hour]
                    if len(rolling) >= 18:
                        result = sum(rolling) / len(rolling)
                        label = '近24小时均值'
            if result is None and count >= 18:
                result = sum(period_values) / count
        elif metric == 'NO2':
            if period_values:
                result = max(period_values)
        else:
            result = _max_running_8(values, start, end)
        level = score(metric, result)
        out.append(dict(code=metric, name=NAMES[metric], value=round(result, 2) if result is not None else None,
                        level=level, band=band(level), count=count, period=label, unit='µg/m³'))
    return out


# Official health advice is grouped for general public and those with heart/lung
# conditions and older people. More specific cards are readable Chinese adaptations.
ADVICE = {
 'low': [
  ('普通人群', '正常通勤、散步和户外运动。', '按日常习惯出行即可。'),
  ('儿童与青少年', '正常上学、户外活动和体育课。', '活动中留意咳嗽、胸闷等不适。'),
  ('老年人', '可以正常散步和开展日常活动。', '按个人身体情况安排活动强度。'),
  ('呼吸系统疾病人群', '可按平时的活动计划外出。', '继续遵循既有治疗和哮喘管理方案。'),
  ('心血管疾病人群', '可按日常习惯进行适度活动。', '遵循既有健康管理安排。'),
  ('户外运动与工作人群', '可按计划运动或工作。', '根据自身状态安排休息和补水。')],
 'moderate': [
  ('普通人群', '通常可以正常出行和开展户外活动。', '如出现咳嗽、眼鼻刺激，适当减少接触污染。'),
  ('儿童与青少年', '可正常上学和活动，身体敏感者适当降低运动强度。', '出现不适时及时休息、调整活动安排。'),
  ('老年人', '可正常外出散步，避免勉强进行高强度运动。', '选择车流较少的路线，并留意身体感受。'),
  ('呼吸系统疾病人群', '根据症状调整户外剧烈活动。', '遵循哮喘等既有管理方案，出现症状时减少暴露。'),
  ('心血管疾病人群', '适当调整户外较费力的活动。', '如出现不适，减少活动强度并按既有方案处理。'),
  ('户外运动与工作人群', '可以继续日常安排，适当控制高强度运动。', '尽量避开繁忙道路和污染较重的路段。')],
 'high': [
  ('普通人群', '建议减少长时间户外停留和高强度活动。', '选择车流较少的路线；出现不适时尽早休息。'),
  ('儿童与青少年', '适当缩短户外体育活动，身体敏感者减少剧烈运动。', '外出时留意呼吸道不适，必要时调整活动地点。'),
  ('老年人', '尽量减少较费力的户外活动。', '短途出行优先选择较少暴露的路线和交通方式。'),
  ('呼吸系统疾病人群', '减少或调整户外剧烈运动。', '随身备好医生开具的常用药物，并遵循个人管理方案。'),
  ('心血管疾病人群', '减少高强度户外活动，避免长时间暴露。', '根据症状和既有医疗建议安排出行。'),
  ('户外运动与工作人群', '减少连续高强度运动，调整工作和休息节奏。', '优先选择低车流路线，必要时缩短户外作业时长。')],
 'very_high': [
  ('普通人群', '尽量减少高强度户外活动，能调整的活动可改在室内。', '减少接触污染的时间；出现不适时及时休息。'),
  ('儿童与青少年', '建议将剧烈体育活动改为室内或低强度活动。', '身体敏感的儿童尤其应留意呼吸道症状。'),
  ('老年人', '尽量减少费力的户外活动。', '外出前做好路线和交通安排，减少暴露时间。'),
  ('呼吸系统疾病人群', '尽量避免户外剧烈运动。', '遵循个人治疗方案，备好医生开具的常用药物。'),
  ('心血管疾病人群', '尽量避免户外高强度活动。', '尽量减少污染暴露，出现症状时按照既有健康方案处理。'),
  ('户外运动与工作人群', '建议调整训练和作业安排，避免长时间剧烈活动。', '尽量缩短暴露时间，优先选择室内或低暴露环境。')]
}


def advice_for(level):
    b = band(level)
    return [dict(group=g, travel=t, protection=p) for g, t, p in ADVICE.get(b, [])]


@lru_cache(maxsize=5)
def _read_historical(path_string, modified_ns):
    by_site_day = defaultdict(list)
    site_counts = defaultdict(lambda: [None, None, 0])
    with open(path_string, 'r', encoding='utf-8-sig', newline='') as handle:
        for row in csv.DictReader(handle):
            site = (row.get('site_id') or '').strip()
            stamp = utc_hour(row.get('timestamp_utc'))
            if not site or stamp is None:
                continue
            day = stamp.date().isoformat()
            bounds = site_counts[site]
            bounds[0] = min(bounds[0], day) if bounds[0] else day
            bounds[1] = max(bounds[1], day) if bounds[1] else day
            bounds[2] += 1
            for metric in METRICS:
                value = valid_number(row.get(metric+'_ugm3'))
                if value is not None:
                    by_site_day[(site, day)].append(dict(metric=metric, timestamp=stamp.isoformat(), value=value, period=3600))
    return by_site_day, site_counts


class HealthAdvice:
    def __init__(self, database, project_root):
        self.database = Path(database)
        self.history_file = Path(project_root) / 'data' / 'health' / 'defra_2025_hourly.csv'

    def _historical(self):
        if not self.history_file.is_file():
            return {}, {}
        return _read_historical(str(self.history_file), self.history_file.stat().st_mtime_ns)

    def sites(self):
        items = []
        if self.database.is_file():
            db = sqlite3.connect(self.database)
            db.row_factory = sqlite3.Row
            try:
                rows = db.execute('''SELECT l.source,l.source_id,l.name,
                    MIN(m.valid_at_utc) AS first_day,MAX(m.valid_at_utc) AS last_day,
                    COUNT(m.value_num) AS records
                    FROM locations l JOIN measurements m
                    ON l.source=m.source AND l.source_id=m.source_id
                    WHERE l.source IN ('laqn','breathe','breathe_wcc')
                      AND m.metric IN ('PM25_CONCENTRATION','PM10_CONCENTRATION','NO2_CONCENTRATION','O3_CONCENTRATION')
                      AND m.value_num IS NOT NULL AND m.value_num>=0
                    GROUP BY l.source,l.source_id,l.name
                    ORDER BY l.source,l.name''').fetchall()
                for x in rows:
                    items.append(dict(source=x['source'], id=x['source_id'], name=x['name'] or x['source_id'],
                                      first=x['first_day'][:10], last=x['last_day'][:10], records=x['records']))
            finally:
                db.close()
        _, historical_sites = self._historical()
        for sid, (first, last, count) in sorted(historical_sites.items()):
            items.append(dict(source='defra2025', id=sid, name=SITE_NAMES.get(sid, sid),
                              first=first, last=last, records=count))
        return {'items': items, 'source_labels': {'laqn': 'LAQN 当前监测', 'breathe': 'Breathe London',
                   'breathe_wcc': 'Westminster', 'defra2025': '2025历史数据（Defra）'},
                'historical_ready': bool(historical_sites)}

    def _live_records(self, source, site, selected_date):
        start = datetime.combine(selected_date - timedelta(days=1), datetime.min.time(), tzinfo=timezone.utc)
        end = datetime.combine(selected_date + timedelta(days=1), datetime.min.time(), tzinfo=timezone.utc)
        db = sqlite3.connect(self.database)
        db.row_factory = sqlite3.Row
        try:
            site_row = db.execute('SELECT name FROM locations WHERE source=? AND source_id=?', (source, site)).fetchone()
            if site_row is None:
                raise LookupError('未找到该监测站')
            rows = db.execute('''SELECT metric,valid_at_utc AS timestamp,value_num AS value,period_seconds AS period
                 FROM measurements WHERE source=? AND source_id=?
                 AND valid_at_utc >= ? AND valid_at_utc < ?
                 AND value_num IS NOT NULL AND value_num >= 0
                 AND metric IN ('PM25_CONCENTRATION','PM10_CONCENTRATION','NO2_CONCENTRATION','O3_CONCENTRATION')
                 ORDER BY valid_at_utc,period_seconds''', (source,site,start.isoformat(),end.isoformat())).fetchall()
            return site_row['name'] or site, [dict(x) for x in rows]
        finally:
            db.close()

    def daily(self, params):
        source = (params.get('source') or '').strip()
        site = (params.get('site') or '').strip()
        day_raw = (params.get('date') or '').strip()
        if source not in ('defra2025', 'laqn', 'breathe', 'breathe_wcc') or not site or len(site)>100:
            raise ValueError('请选择监测站')
        try:
            selected_day = date.fromisoformat(day_raw)
        except ValueError:
            raise ValueError('请选择有效日期') from None
        if not (date(2000,1,1) <= selected_day <= date(2100,12,31)):
            raise ValueError('日期不在支持范围内')
        if source == 'defra2025':
            by_site_day, sites = self._historical()
            if site not in sites:
                raise LookupError('未导入该监测站的2025年数据')
            rows = (by_site_day.get((site, (selected_day-timedelta(days=1)).isoformat()), [])+
                    by_site_day.get((site, day_raw), []))
            name = SITE_NAMES.get(site, site)
        else:
            name, rows = self._live_records(source, site, selected_day)
        hourly = to_hourly(rows)
        metrics = _daily_metrics(hourly, selected_day)
        scored = [m for m in metrics if m['level'] is not None]
        top = max((m['level'] for m in scored), default=None)
        dominant = [m['name'] for m in scored if m['level'] == top]
        labels = {'low': '适合正常出行', 'moderate': '可正常出行，敏感人群适当调整',
                  'high': '建议减少长时间户外活动', 'very_high': '建议减少户外剧烈运动',
                  'missing': '该日暂无足够监测数据'}
        b = band(top)
        return dict(source=source, site=site, name=name, date=day_raw,
                    level=top, band=b, band_label=BANDS[b], headline=labels[b],
                    dominant=dominant, pollutants=metrics, advice=advice_for(top),
                    available_metrics=len(scored), unit='µg/m³',
                    data_note='按2025年逐小时历史记录计算' if source=='defra2025' else '按已有监测小时记录计算')
