# -*- coding: utf-8 -*-
"""Copy previously downloaded real 2025 Defra hourly CSV into health module."""
import argparse
import csv
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / 'data' / 'health' / 'defra_2025_hourly.csv'
NEEDED = {'timestamp_utc','site_id','PM25_ugm3','PM10_ugm3','NO2_ugm3','O3_ugm3'}


def candidate_files():
    p = ROOT
    relatives = (
        p/'data'/'london_2025_hourly.csv',
        p/'processed'/'london_2025_hourly.csv',
        p.parent/'data'/'london_2025_hourly.csv',
        p.parent/'processed'/'london_2025_hourly.csv',
        p.parent/'London_AirWatch_2025_V1'/'data'/'london_2025_hourly.csv',
        p.parent/'London_AirQuality_2025_package'/'data'/'london_2025_hourly.csv',
        p.parent/'London_AirQuality_2025_package'/'processed'/'london_2025_hourly.csv',
        p.parent.parent/'data'/'london_2025_hourly.csv',
        p.parent.parent/'processed'/'london_2025_hourly.csv',
        p.parent.parent/'London_AirQuality_2025_package'/'data'/'london_2025_hourly.csv',
    )
    return list(dict.fromkeys(x.resolve() for x in relatives if x.is_file()))


def inspect(path):
    count = 0
    pm = 0
    sites = set()
    with path.open('r',encoding='utf-8-sig',newline='') as file:
        reader = csv.DictReader(file)
        if not NEEDED.issubset(reader.fieldnames or ()):
            raise ValueError('不是之前使用的2025年逐小时CSV格式')
        for row in reader:
            if not row.get('timestamp_utc','').startswith('2025-'):
                continue
            sites.add(row.get('site_id',''))
            count += 1
            pm += int(bool(row.get('PM25_ugm3','').strip())) + int(bool(row.get('PM10_ugm3','').strip()))
    if count < 24 or not sites:
        raise ValueError('CSV记录数过少')
    return count, pm, len(sites)


def import_csv(path=None, verbose=True):
    candidates = [Path(path).resolve()] if path else candidate_files()
    if DEST.exists() and (not path):
        candidates.append(DEST)
    ranked = []
    for file in candidates:
        try:
            info=inspect(file)
            if verbose: print(f'Found: {file} | rows={info[0]}, PM values={info[1]}, sites={info[2]}')
            ranked.append((info[1], info[0], file, info))
        except (OSError, ValueError) as err:
            if verbose: print(f'SKIP: {file}: {err}')
    if not ranked:
        if verbose: print('No historical CSV found. Live LAQN health advice will still work.')
        return None
    # Prefer the most complete PM data first. Never silently replace it with an older incomplete copy.
    ranked.sort(key=lambda x: (x[0], x[1]), reverse=True)
    _, _, winner, info = ranked[0]
    DEST.parent.mkdir(parents=True, exist_ok=True)
    if winner != DEST.resolve():
        shutil.copy2(winner, DEST)
    if verbose: print(f'IMPORTED: {info[0]} hourly station rows, {info[1]} PM observations, {info[2]} sites -> {DEST}')
    return dict(rows=info[0], pm_values=info[1], sites=info[2], path=str(DEST))


def main():
    parser=argparse.ArgumentParser(description='Import genuine Defra 2025 hourly CSV, without touching UrbanFlow SQLite')
    parser.add_argument('path', nargs='?', help='optional explicit path to london_2025_hourly.csv')
    args=parser.parse_args()
    import_csv(args.path)

if __name__=='__main__': main()
