# -*- coding: utf-8 -*-
"""Idempotent small additive patch for UrbanFlow; backups before edits."""
from __future__ import annotations
from datetime import datetime
from pathlib import Path
import shutil
import subprocess
import sys

SOURCE = Path(__file__).resolve().parent
PANEL = '''
    <!-- Daily travel and health recommendations (new additive module) -->
    <section id="healthAdviceModule" class="panel health-advice">
      <div class="panel-title"><div><h2>每日空气质量与健康出行建议</h2><p class="health-intro">按日期和监测站查看不同人群的出行建议、防护措施</p></div></div>
      <div class="health-controls">
        <label>监测数据<select id="healthDataset"></select></label>
        <label>监测站<select id="healthStation"></select></label>
        <label>日期<input type="date" id="healthDate"></label>
        <div class="health-date-buttons"><button type="button" id="healthPrev" title="上一天">‹</button><button type="button" id="healthNext" title="下一天">›</button><button type="button" id="healthLatest">最近有数据</button></div>
      </div>
      <div id="healthStatus" aria-live="polite">正在读取监测数据…</div>
      <div id="healthMetrics" class="health-metrics"></div>
      <h3 class="health-section-subtitle">不同人群的出行与防护参考</h3>
      <div id="healthPeople" class="health-people"></div>
      <p id="healthDetail" class="health-detail"></p>
    </section>
'''


def project_root():
    for root in (SOURCE, SOURCE.parent):
        if (root/'index.html').is_file() and (root/'tools'/'server.py').is_file():
            return root
    raise SystemExit('ERROR: Put this add-on folder directly inside the London_UrbanFlow-main project, then run again.')


def backup_write(path, content, root):
    current = path.read_text(encoding='utf-8')
    if current == content:
        return False
    backups = root/'health_backup'
    backups.mkdir(exist_ok=True)
    target=backups/(path.relative_to(root).as_posix().replace('/','__')+'.before_health.bak')
    if not target.exists(): shutil.copy2(path, target)
    path.write_text(content,encoding='utf-8')
    return True


def patch_html(value):
    if 'assets/health_advice.css' not in value:
        if '</head>' not in value: raise ValueError('index.html has no </head>')
        value=value.replace('</head>', '<link rel="stylesheet" href="assets/health_advice.css">\n<script src="assets/health_advice.js" defer></script>\n</head>',1)
    if 'id="healthAdviceMini"' not in value:
        anchor='<div id="citizenCard"'
        start = value.find(anchor)
        if start<0: raise ValueError('index.html missing citizenCard')
        end=value.find('</div>',start)
        if end<0: raise ValueError('index.html malformed citizenCard')
        end+=6
        value=value[:end]+'\n        <div id="healthAdviceMini"></div>'+value[end:]
    if 'id="healthAdviceModule"' not in value:
        anchor='<section class="panel overview-bottom">'
        if anchor not in value: raise ValueError('index.html missing overview-bottom')
        value=value.replace(anchor,PANEL+'\n    '+anchor,1)
    return value


def patch_server(value):
    if 'from health_advice import HealthAdvice' not in value:
        anchor='import traffic_history'
        if anchor not in value: raise ValueError('server.py import location not recognized')
        value=value.replace(anchor,anchor+'\nfrom health_advice import HealthAdvice',1)
    if 'STATIC.update({"/assets/health_advice.js"' not in value:
        anchor='\n\nclass LocalServer'
        if anchor not in value: raise ValueError('server.py STATIC section not recognized')
        value=value.replace(anchor,'\nSTATIC.update({"/assets/health_advice.js", "/assets/health_advice.css"})'+anchor,1)
    if '"/api/health/sites"' not in value:
        anchor='routes = {'
        if anchor not in value: raise ValueError('server.py api routes not recognized')
        value=value.replace(anchor,anchor+'"/api/health/sites": lambda: self.server.health.sites(),\n                  "/api/health/daily": lambda: self.server.health.daily(params),\n                  ',1)
    if 'server.health = HealthAdvice' not in value:
        anchor='server.updates = UpdateManager(database)'
        if anchor not in value: raise ValueError('server.py server construction not recognized')
        value=value.replace(anchor,anchor+'\n    server.health = HealthAdvice(database, ROOT)',1)
    return value


def patch_city(value):
    anchor='async function selectFeature(kind, f, lngLat = null, withPopup = true) {'
    if 'urbanflow:station-selected' in value: return value
    start=value.find(anchor)
    if start < 0: raise ValueError('city.js map selection hook not recognized')
    p=value.find('const p = f.properties;',start)
    if p<0: raise ValueError('city.js map selection metadata not recognized')
    p+=len('const p = f.properties;')
    addition='\n    if ((!previous || previous.kind !== kind || previous.feature.properties.id !== p.id || previous.feature.properties.source !== p.source) && typeof CustomEvent === "function" && typeof window.dispatchEvent === "function")\n      window.dispatchEvent(new CustomEvent("urbanflow:station-selected", {detail:{kind,source:p.source||"",id:p.id,name:p.name}}));'
    return value[:p]+addition+value[p:]


def write_import_launcher(root):
    path = root/'08_IMPORT_2025_HEALTH.bat'
    if path.exists(): return
    path.write_text('''@echo off\nchcp 65001 >nul\ncd /d "%~dp0"\nset "PYTHON=python"\nif exist "D:\\anaconda3\\envs\\gpu\\python.exe" set "PYTHON=D:\\anaconda3\\envs\\gpu\\python.exe"\n"%PYTHON%" "tools\\import_health_2025.py" %*\npause\n''', encoding='utf-8')


def main():
    root=project_root()
    print('Project:',root)
    for relative in ('assets/health_advice.css','assets/health_advice.js','tools/health_advice.py','tools/import_health_2025.py'):
        destination=root/relative
        destination.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(SOURCE/relative,destination) if (SOURCE/relative).resolve()!=destination.resolve() else None
    tests_target = root/'tests'/'test_health_advice.py'
    tests_target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(SOURCE/'tests'/'test_health_advice.py',tests_target)
    for relative,fn in [('index.html',patch_html),('tools/server.py',patch_server),('assets/city.js',patch_city)]:
        path=root/relative
        old=path.read_text(encoding='utf-8')
        new=fn(old)
        changed=backup_write(path,new,root)
        print(('PATCHED: ' if changed else 'ALREADY: ')+relative)
    write_import_launcher(root)
    subprocess.run([sys.executable,str(root/'tools'/'import_health_2025.py')],check=True)
    print('\nINSTALLATION OK. Restart 02_OPEN_DASHBOARD.bat, then Ctrl+F5 in browser.')
    print('Previous versions of edited files are in: health_backup/')

if __name__=='__main__':
    try: main()
    except Exception as exc:
        print('INSTALL FAILED:',type(exc).__name__,exc)
        raise
