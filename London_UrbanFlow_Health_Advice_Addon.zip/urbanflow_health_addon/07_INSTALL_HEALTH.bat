@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PYTHON=python"
if exist "D:\anaconda3\envs\gpu\python.exe" set "PYTHON=D:\anaconda3\envs\gpu\python.exe"
echo Installing daily health advice add-on...
"%PYTHON%" "install_health.py"
if errorlevel 1 echo Installation failed. Check the project folder structure.
echo.
pause
