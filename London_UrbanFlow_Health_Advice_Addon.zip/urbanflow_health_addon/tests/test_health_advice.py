# -*- coding: utf-8 -*-
"""Run with python -m unittest discover -s urbanflow_health_addon/tests -v after install."""
import csv
from datetime import datetime, timedelta, timezone
from pathlib import Path
import json
import sqlite3
import sys
import tempfile
import unittest

ROOT=next((p for p in Path(__file__).resolve().parents if (p/'tools'/'live_store.py').is_file()), Path(__file__).resolve().parents[2])
sys.path.insert(0,str(ROOT/'tools'))
from health_advice import HealthAdvice, score, band, normalize_metric, to_hourly, _daily_metrics
import live_store as store

class Tests(unittest.TestCase):
    def test_score_thresholds(self):
        for metric,x,a,b in [('PM25',35.49,3,4),('PM10',50.49,3,4),('NO2',200.49,3,4),('O3',100.49,3,4)]:
            self.assertEqual(score(metric,x),a)
            self.assertEqual(score(metric,x+0.02),b)
        self.assertEqual(score('PM25',71),10)
        self.assertEqual(score('PM25',-3),None)
        self.assertIsNone(score('O3',float('nan')))
    def test_bands(self):
        self.assertEqual([band(i) for i in (1,3,4,6,7,9,10,None)],
                         ['low','low','moderate','moderate','high','high','very_high','missing'])
    def test_metrics(self):
        day=datetime(2025,6,1,tzinfo=timezone.utc)
        rows=[]
        for k in range(24):
            stamp=(day+timedelta(hours=k)).isoformat()
            rows.extend([dict(metric='PM25_CONCENTRATION',timestamp=stamp,value=20,period=3600),
                         dict(metric='PM10_CONCENTRATION',timestamp=stamp,value=30,period=3600),
                         dict(metric='NO2_CONCENTRATION',timestamp=stamp,value=42 if k < 23 else 201,period=3600),
                         dict(metric='O3_CONCENTRATION',timestamp=stamp,value=164,period=3600)])
        metrics=_daily_metrics(to_hourly(rows),day.date())
        self.assertEqual([m['level'] for m in metrics],[2,2,4,7])
        self.assertEqual(metrics[3]['period'],'最大8小时均值')
    def test_pm_data_insufficient(self):
        day=datetime(2025,6,1,tzinfo=timezone.utc)
        rows=[dict(metric='PM25_CONCENTRATION',timestamp=(day+timedelta(hours=i)).isoformat(),value=88,period=3600) for i in range(10)]
        metrics=_daily_metrics(to_hourly(rows),day.date())
        self.assertIsNone(metrics[0]['level'])
        self.assertEqual(metrics[0]['count'],10)
    def test_aggregate_quarters(self):
        base='2025-06-01T12:'
        rows=[dict(metric='PM25_CONCENTRATION',timestamp=base+minute+':00+00:00',value=i*10,period=900) for i,minute in enumerate(('00','15','30','45'),1)]
        hourly=to_hourly(rows)
        self.assertEqual(len(hourly['PM25']),1)
        self.assertEqual(list(hourly['PM25'].values())[0],25)
        rows.append(dict(metric='PM25_CONCENTRATION',timestamp=base+'00:00+00:00',value=99,period=3600))
        self.assertEqual(list(to_hourly(rows)['PM25'].values())[0],99)
    def test_metric_aliases(self):
        self.assertEqual(normalize_metric('PM25_CONCENTRATION'),'PM25')
        self.assertIsNone(normalize_metric('NO2_INDEX'))
    def test_historical_and_live_sqlite(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            db_path=root/'live.sqlite3'
            with store.connect(db_path) as db:
                store.location(db,'laqn','TEST','Test station',lat=51.5,lon=-.1)
                for i in range(24):
                    stamp=(datetime(2025,7,1,tzinfo=timezone.utc)+timedelta(hours=i)).isoformat(timespec='seconds')
                    store.measurement(db,'laqn','TEST','PM25_CONCENTRATION',stamp,stamp,3600,'test',value_num=23,unit='ug/m3')
                    store.measurement(db,'laqn','TEST','NO2_CONCENTRATION',stamp,stamp,3600,'test',value_num=10,unit='ug/m3')
                db.commit()
            service=HealthAdvice(db_path,root)
            self.assertTrue(any(x['source']=='laqn' for x in service.sites()['items']))
            day=service.daily({'source':'laqn','site':'TEST','date':'2025-07-01'})
            self.assertEqual(day['level'],2)
            self.assertEqual(len(day['advice']),6)
            self.assertEqual(day['pollutants'][0]['count'],24)
            self.assertIsNone(day['pollutants'][3]['level'])
            with self.assertRaises(LookupError):
                service.daily({'source':'laqn','site':'MISSING','date':'2025-07-01'})
            self.assertRaises(ValueError,service.daily,{'source':'laqn','site':'TEST','date':'wrong'})
            historical=root/'data'/'health'/'defra_2025_hourly.csv'
            historical.parent.mkdir(parents=True,exist_ok=True)
            with historical.open('w',encoding='utf-8',newline='') as out:
                writer=csv.DictWriter(out,fieldnames=['timestamp_utc','site_id','PM25_ugm3','PM10_ugm3','NO2_ugm3','O3_ugm3'])
                writer.writeheader()
                for i in range(24):
                    writer.writerow(dict(timestamp_utc=(datetime(2025,7,2,tzinfo=timezone.utc)+timedelta(hours=i)).isoformat(),site_id='BEX',PM25_ugm3='55',PM10_ugm3='60',NO2_ugm3='20',O3_ugm3=''))
            sites=service.sites()['items']
            self.assertIn('defra2025',[x['source'] for x in sites])
            history=service.daily({'source':'defra2025','site':'BEX','date':'2025-07-02'})
            self.assertEqual(history['level'],7)
            self.assertEqual(history['dominant'],['PM₂.₅'])
            self.assertEqual(history['pollutants'][3]['level'],None)
    def test_out_of_range(self):
        with tempfile.TemporaryDirectory() as tmp:
            service=HealthAdvice(Path(tmp)/'db.sqlite3',Path(tmp))
            with self.assertRaises(ValueError): service.daily({'source':'laqn','site':'T','date':'1800-01-01'})

if __name__=='__main__':unittest.main()
