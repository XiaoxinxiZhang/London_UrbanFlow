/* UrbanFlow daily air quality / travel advice — standalone, no third-party libraries. */
(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, x => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;', "'":'&#39;'}[x]));
  const state = {sites: [], labels: {}, source: '', site: '', day: '', generation: 0, loaded: false};

  function groupOptions() {
    const options = [...new Set(state.sites.map(x => x.source))];
    $('healthDataset').innerHTML = options.map(v => `<option value="${esc(v)}">${esc(state.labels[v] || v)}</option>`).join('');
  }
  function filteredSites() { return state.sites.filter(x => x.source === state.source); }
  function selectSource(source, id = '') {
    if (!state.sites.some(x => x.source === source)) return;
    const was = state.source;
    state.source = source;
    $('healthDataset').value = source;
    const items = filteredSites();
    $('healthStation').innerHTML = items.map(x => `<option value="${esc(x.id)}">${esc(x.name)} · ${esc(x.id)}</option>`).join('');
    const preferred = items.find(x => x.id === id) || items.find(x => x.id === state.site && source === was) || items[0];
    if (!preferred) return;
    state.site = preferred.id;
    $('healthStation').value = state.site;
    changeSiteDate(preferred);
  }
  function changeSiteDate(selected, reset = true) {
    if (!selected) return;
    $('healthDate').min = selected.first;
    $('healthDate').max = selected.last;
    if (reset && (!state.day || state.day < selected.first || state.day > selected.last || state.source === 'defra2025'))
      state.day = selected.last;
    if (!state.day || state.day < selected.first || state.day > selected.last)
      state.day = selected.last;
    $('healthDate').value = state.day;
  }
  function todayButton() {
    const item = filteredSites().find(x => x.id === state.site);
    if (!item) return;
    state.day = item.last;
    $('healthDate').value = state.day;
    loadDaily();
  }
  function offsetDate(delta) {
    if (!state.day) return;
    const d = new Date(state.day + 'T12:00:00Z');
    d.setUTCDate(d.getUTCDate() + delta);
    const next = d.toISOString().slice(0, 10);
    const input = $('healthDate');
    if (input.min && next < input.min || input.max && next > input.max) return;
    state.day = next;
    input.value = next;
    loadDaily();
  }
  function render(data) {
    const colour = data.band || 'missing';
    const level = data.level === null ? '—' : `${data.level} / 10`;
    const dominant = data.dominant?.length ? '主要指标：' + data.dominant.join('、') : '暂无当日污染物统计';
    $('healthStatus').innerHTML = `<div class="health-grade health-${colour}">
      <div><span class="health-grade-kicker">${esc(data.date)} · ${esc(data.name)}</span>
      <h3>${esc(data.band_label)} <span>${esc(level)}</span></h3>
      <strong>${esc(data.headline)}</strong>
      <p>${esc(dominant)}</p></div>
      <span class="health-grade-disc">${esc(data.band_label)}</span>
    </div>`;
    $('healthMetrics').innerHTML = (data.pollutants || []).map(item => `<div class="health-pollutant">
      <div class="health-pollutant-head"><b>${esc(item.name)}</b><span>${item.level === null ? '暂无数值' : esc(item.level + '级')}</span></div>
      <div class="health-pollutant-value">${item.value === null ? '—' : esc(item.value.toFixed(1))}<small>${item.value === null ? '' : 'µg/m³'}</small></div>
      <div class="health-pollutant-foot">${esc(item.period)} · ${esc(item.count)}小时</div></div>`).join('');
    $('healthPeople').innerHTML = (data.advice && data.advice.length ? data.advice.map(item => `
      <article class="health-person health-${colour}">
        <h4>${esc(item.group)}</h4>
        <p><span>出行建议</span>${esc(item.travel)}</p>
        <p><span>防护措施</span>${esc(item.protection)}</p>
      </article>`).join('') : '<p class="health-no-data">该日暂无足够的监测值，请选择其他日期或站点。</p>');
    $('healthDetail').textContent = 'PM₂.₅、PM₁₀采用日均值，NO₂采用最大小时值，O₃采用最大8小时滑动均值。';
    const mini = $('healthAdviceMini');
    if (mini) {
      const ordinary = data.advice?.[0];
      const risk = data.advice?.[3];
      mini.innerHTML = `<div class="health-mini-card health-${colour}"><div class="health-mini-head">每日出行建议 <strong>${esc(data.band_label)} · ${esc(level)}</strong></div>
        <p>${esc(data.date)} · ${esc(data.name)}</p>
        <p>${esc(ordinary?.travel || data.headline)}</p>
        ${risk ? `<p class="health-mini-risk">敏感人群：${esc(risk.travel)}</p>` : ''}
        <button id="healthGoDetail" type="button">查看分人群建议</button></div>`;
      $('healthGoDetail')?.addEventListener('click', () => {
        $('healthAdviceModule')?.scrollIntoView({behavior:'smooth', block:'start'});
      });
    }
  }
  async function loadDaily() {
    if (!state.source || !state.site || !state.day) return;
    const n = ++state.generation;
    $('healthStatus').innerHTML = '<p class="health-loading">正在计算当日出行建议…</p>';
    try {
      const q = new URLSearchParams({source:state.source,site:state.site,date:state.day});
      const response = await fetch('/api/health/daily?' + q, {cache:'no-store'});
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || '暂时无法加载');
      if (n !== state.generation) return;
      render(data);
    } catch (err) {
      if (n !== state.generation) return;
      $('healthStatus').textContent = '查询失败：' + err.message;
      $('healthMetrics').textContent = '';
      $('healthPeople').textContent = '';
    }
  }
  function selectMapStation(detail) {
    if (!detail || detail.kind !== 'air' || !detail.source || !detail.id) return;
    const target = state.sites.find(x => x.source === detail.source && x.id === detail.id);
    if (!target) return;
    selectSource(detail.source, detail.id);
    state.day = target.last;
    $('healthDate').value = state.day;
    loadDaily();
  }
  async function init() {
    if (!$('healthAdviceModule')) return;
    try {
      const response = await fetch('/api/health/sites', {cache:'no-store'});
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || '无数据');
      state.sites = payload.items || [];
      state.labels = payload.source_labels || {};
      if (!state.sites.length) {
        $('healthStatus').textContent = '还没有可分析的监测数据，请先点击顶部“更新数据”。';
        return;
      }
      groupOptions();
      const preferred = state.sites.some(x => x.source === 'defra2025') ? 'defra2025' :
        state.sites.some(x => x.source === 'laqn') ? 'laqn' : state.sites[0].source;
      selectSource(preferred);
      state.loaded = true;
      await loadDaily();
      $('healthDataset').addEventListener('change', () => { state.day=''; selectSource($('healthDataset').value); loadDaily(); });
      $('healthStation').addEventListener('change', () => {
        state.site = $('healthStation').value;
        const entry = filteredSites().find(x => x.id === state.site);
        state.day = '';
        changeSiteDate(entry);
        loadDaily();
      });
      $('healthDate').addEventListener('change', () => { state.day = $('healthDate').value; loadDaily(); });
      $('healthPrev').addEventListener('click', () => offsetDate(-1));
      $('healthNext').addEventListener('click', () => offsetDate(1));
      $('healthLatest').addEventListener('click', todayButton);
    } catch (err) { $('healthStatus').textContent = '出行建议模块暂不可用：' + err.message; }
  }
  window.addEventListener('urbanflow:station-selected', e => {
    if (state.loaded) selectMapStation(e.detail);
  });
  // Existing collector refreshes its own map; update the list without losing the date if possible.
  window.addEventListener('airwatch:refreshed', async () => {
    const current = {source:state.source, site:state.site, date:state.day};
    try {
      const r = await fetch('/api/health/sites',{cache:'no-store'});
      const d = await r.json();
      if (r.ok && Array.isArray(d.items) && d.items.length) {
        state.sites=d.items; state.labels=d.source_labels || state.labels;
        groupOptions(); selectSource(current.source || d.items[0].source,current.site);
        const item = filteredSites().find(x=>x.id===state.site);
        if (item && current.date >= item.first && current.date <= item.last) {state.day=current.date; $('healthDate').value=current.date;}
        loadDaily();
      }
    } catch (_) {}
  });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
