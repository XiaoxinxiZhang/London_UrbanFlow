@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0.."
set "PY=D:\anaconda3\envs\gpu\python.exe"
if defined AIRWATCH_PYTHON if exist "%AIRWATCH_PYTHON%" set "PY=%AIRWATCH_PYTHON%"
if not exist "%PY%" (
  echo Python not found. Edit PY in this file, then retry.
  pause
  exit /b 1
)
if not exist "tools\collect_laqn_now.py" (
  echo Run 00_INSTALL_SSL_FIX.bat first.
  pause
  exit /b 1
)
echo Collecting LAQN only, to make air quality data visible on the map...
"%PY%" "tools\collect_laqn_now.py" --sites 16
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (echo Done. Refresh the web dashboard; use LAQN, 1 hour, 48 hours.) else (echo See error above; existing data was preserved.)
pause
exit /b %RC%
