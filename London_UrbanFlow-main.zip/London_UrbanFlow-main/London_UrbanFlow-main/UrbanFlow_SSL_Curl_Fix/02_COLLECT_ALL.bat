@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0.."
set "PY=D:\anaconda3\envs\gpu\python.exe"
if defined AIRWATCH_PYTHON if exist "%AIRWATCH_PYTHON%" set "PY=%AIRWATCH_PYTHON%"
if not exist "%PY%" (
  echo Python not found. Edit PY in this file, then retry.
  pause
  exit /b 1
)
echo Running all feeds. Some may fail if the service or token is unavailable.
"%PY%" "tools\collect_live.py" run-once --force
set "RC=%ERRORLEVEL%"
echo.
echo The database was not cleared; view per-source results above.
pause
exit /b %RC%
