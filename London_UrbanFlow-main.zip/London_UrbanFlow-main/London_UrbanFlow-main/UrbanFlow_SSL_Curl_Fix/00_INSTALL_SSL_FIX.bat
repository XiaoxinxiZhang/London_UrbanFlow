@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "PY=D:\anaconda3\envs\gpu\python.exe"
if defined AIRWATCH_PYTHON if exist "%AIRWATCH_PYTHON%" set "PY=%AIRWATCH_PYTHON%"
if not exist "%PY%" (
  echo Python not found. Edit PY in this file, then retry.
  pause
  exit /b 1
)
echo Adding SSL fallback to existing UrbanFlow collector (without replacing database)...
"%PY%" "install_ssl_fix.py"
set "RC=%ERRORLEVEL%"
echo.
pause
exit /b %RC%
