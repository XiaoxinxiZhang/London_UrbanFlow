London UrbanFlow — Windows SSL 网络采集修复包

诊断依据：Python访问LAQN、TfL、Met Office均出现SSLError；同一机器curl.exe访问LAQN返回HTTP 200和有效JSON。
解决方式：保留原采集程序的urllib方式；遇SSL/TLS故障时用Windows curl.exe在正常证书验证下自动重试。

一、放置位置
将整个 UrbanFlow_SSL_Curl_Fix 文件夹放到 London_UrbanFlow-main 项目根目录，与 index.html 和 tools 文件夹并列。
不要放进 tools 文件夹，不要把文件散开放置。

二、使用
1. 双击 00_INSTALL_SSL_FIX.bat：只修改 tools/collect_live.py 的一段网络请求代码，并备份原文件；添加两个新Python文件。
2. 双击 01_COLLECT_LAQN.bat：先抓取LAQN监测站、最新小时指数和部分站点近几天的空气质量浓度。
3. 重新打开/刷新 UrbanFlow 网页，在城市总览选择“LAQN”、最新值粒度“1小时”、时间范围“最近48小时”，点击“应用筛选”。
4. 可选：双击 02_COLLECT_ALL.bat 继续采集所有支持的来源（需相应数据服务可用/密钥有效）。

三、成功标志
01_COLLECT_LAQN.bat 最后出现 LAQN stations: >0 和 observations: >0。
PM2.5 rows 大于0时，PM2.5图层应有相应站点可显示。若有站点无PM2.5值，可先选择 NO2 或 O3 查看。

四、说明
- 这个补丁不删除或重建 SQLite，不改地图、不改自行车、不修改ORS与Met Office密钥。
- Breathe London若旧接口已变化，后续可能仍需单独处理；SSL修复无法保证第三方服务返回有效格式。
- curl.exe仍执行正常HTTPS证书校验，未采用 -k 或关闭SSL验证。
- 不要将包含API密钥的日志发给他人；本补丁不会将密钥写入终端日志。
- 安装器检测到不匹配的collector版本会停止，不会盲目覆盖。

五、手动运行（PowerShell，须在项目根目录）
& 'D:\anaconda3\envs\gpu\python.exe' '.\tools\collect_laqn_now.py' --sites 16
& 'D:\anaconda3\envs\gpu\python.exe' '.\tools\collect_live.py' run-once --force
