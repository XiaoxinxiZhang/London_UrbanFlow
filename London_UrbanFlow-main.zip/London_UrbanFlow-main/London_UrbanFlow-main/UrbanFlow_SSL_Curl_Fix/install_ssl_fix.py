#!/usr/bin/env python3
"""Safely add an SSL curl fallback to the existing UrbanFlow collector."""
from pathlib import Path
import shutil
import sys


ANCHOR_IMPORT = 'import live_sources as parsers'
EXISTING_BLOCK = '''                    req=urllib.request.Request(url,headers=headers)
                    with urllib.request.urlopen(req,timeout=10 if job=="breathe_web_reconcile" else 25) as response:
                        status,raw=response.status,response.read()'''
NEW_BLOCK = '''                    status,raw=open_https(url,headers,timeout=10 if job=="breathe_web_reconcile" else 25)'''
NEW_IMPORT = 'from secure_curl import open_https'


def install(root, package):
    root=Path(root).resolve()
    source=root/'tools'/'collect_live.py'
    if not source.is_file():
        raise FileNotFoundError(f'Project collector not found: {source}')
    content=source.read_text(encoding='utf-8-sig')
    if NEW_IMPORT in content and NEW_BLOCK in content:
        print('SSL fallback already installed; keeping existing collect_live.py')
        change=False
    elif ANCHOR_IMPORT in content and EXISTING_BLOCK in content and NEW_IMPORT not in content:
        content=content.replace(ANCHOR_IMPORT, ANCHOR_IMPORT+'\n'+NEW_IMPORT,1)
        content=content.replace(EXISTING_BLOCK,NEW_BLOCK,1)
        backup=source.with_name('collect_live.py.before_ssl_fix.bak')
        if not backup.exists():
            shutil.copy2(source,backup)
            print('Backup:', backup)
        source.write_text(content,encoding='utf-8')
        change=True
    else:
        raise RuntimeError('This collector layout differs from the supported version. No files changed; please send tools/collect_live.py for a tailored patch.')
    for name in ('secure_curl.py','collect_laqn_now.py'):
        src=package/'assets'/name
        dst=root/'tools'/name
        shutil.copy2(src,dst)
        print('Installed:',dst)
    print('OK: SSL curl fallback '+('installed' if change else 'verified'))
    print('Next: run 01_COLLECT_LAQN.bat in this fix folder.')


def main():
    package=Path(__file__).resolve().parent
    root=package.parent
    try:
        install(root,package)
    except (FileNotFoundError,RuntimeError,OSError,UnicodeError) as exc:
        print('INSTALL FAILED:',str(exc))
        return 1
    return 0

if __name__=='__main__':sys.exit(main())
