London UrbanFlow data collection diagnosis (read-only)

Copy `tools` folder and `08_DIAGNOSE_AIR_DATA.bat` to the root directory of your existing London_UrbanFlow-main project, merging the existing tools folder.

Double-click 08_DIAGNOSE_AIR_DATA.bat. It reads your existing SQLite database and uses Windows curl to check the two official LAQN endpoints. It does not change data, settings, API keys, or original code.

Report questions:
- locations = 0 -> no station metadata downloaded.
- measurements = 0 -> no pollutant measurements downloaded.
- LAQN PM2.5 15 min = 0 but 60 min > 0 -> set site grain to 1 hour instead of 15 minutes.
- SSL error for Python but curl HTTP 200 -> Python SSL/environment network compatibility likely.
- Breathe London old endpoint may no longer support unauthenticated legacy calls; this is independent of LAQN.

If you ask for help, share `job_state` and errors output but not the API tokens.
